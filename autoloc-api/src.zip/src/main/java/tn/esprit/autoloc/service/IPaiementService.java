package tn.esprit.autoloc.service;

import tn.esprit.autoloc.domain.Paiement;

/** Paiement en lecture seule : seules findById et findAll sont utilisables. */
public interface IPaiementService extends IGenericService<Paiement, Long> {
}
