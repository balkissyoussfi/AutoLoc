package tn.esprit.autoloc.service;

import tn.esprit.autoloc.domain.Paiement;

public interface IPaiementService extends IReadGenericService<Paiement, Long> {
}
